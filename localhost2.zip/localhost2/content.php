<?php
sleep(seconds:1);
    if ($_POST['name'] == "Admin"){
        echo "fail";
    }else{
        echo $_POST['name'];
    }

echo "Данные: строка - ".$_POST['name'].", цифра - ".$_POST['password'];
