function funcBefore() {
    $("#information").text("Ожидание данных...")
}

function funcSuccess(data) {
    $("#information").text(data)
}

$(document).ready(function (){
    $("#load").bind("click", function(){
        let admin = "Admin";
        $.ajax({
            url: "content.php",
            type: "POST",
            data: ({name: admin, password: admin}),
            dataType: "html",
            beforeSend: funcBefore,
            success: funcSuccess
        });
    }) ;
});

function funcSuccess(data) {
    if (data == "fail"){
        alert("Имя занято!");
        $("#information").text ("");
    }else{
        $("#information").text (data);
    };    
}