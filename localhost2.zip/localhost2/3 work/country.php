<?php
if ($_GET["country"] == 1) {
    echo json_encode(array(
        "1" => "Вашингтон",
        "2" => "Сиэтл"
    ))
}